# Tests package init
