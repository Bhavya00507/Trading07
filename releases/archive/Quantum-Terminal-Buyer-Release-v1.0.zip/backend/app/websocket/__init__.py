# WebSocket package init
